#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

constexpr uint8_t PIN_TRIG = 5;
constexpr uint8_t PIN_ECHO = 18;
constexpr uint8_t PIN_BUZZER = 19;
constexpr float MIN_RANGE_CM = 2.0f;
constexpr float MAX_RANGE_CM = 400.0f;
constexpr uint8_t N_SAMPLES = 5;

LiquidCrystal_I2C lcd(0x27, 16, 2);

float samples[N_SAMPLES];
uint8_t sampleIdx = 0;
uint8_t sampleCount = 0;
uint8_t errorCount = 0;

float readDistanceCm() {
  digitalWrite(PIN_TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(PIN_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);

  unsigned long us = pulseIn(PIN_ECHO, HIGH, 30000);
  if (us == 0) return NAN;
  float cm = us * 0.0343f / 2.0f;
  if (cm < MIN_RANGE_CM || cm > MAX_RANGE_CM) return NAN;
  return cm;
}

float movingAverage(float value) {
  samples[sampleIdx] = value;
  sampleIdx = (sampleIdx + 1) % N_SAMPLES;
  if (sampleCount < N_SAMPLES) sampleCount++;
  float sum = 0;
  for (uint8_t i = 0; i < sampleCount; i++) sum += samples[i];
  return sum / sampleCount;
}

void showDistance(float d) {
  char line1[17];
  snprintf(line1, sizeof(line1), "Dist: %3d cm    ", (int)d);
  lcd.setCursor(0, 0);
  lcd.print(line1);

  int n = map(constrain((int)d, 0, 150), 150, 0, 0, 16);
  lcd.setCursor(0, 1);
  for (int i = 0; i < 16; i++) lcd.print(i < n ? '#' : ' ');
}

void showError() {
  lcd.setCursor(0, 0);
  lcd.print("Sensor error    ");
  lcd.setCursor(0, 1);
  lcd.print("                ");
}

void beepForDistance(float d) {
  static uint32_t lastBeep = 0;
  uint32_t now = millis();
  if (d < 20) {
    tone(PIN_BUZZER, 2000);
    return;
  }
  uint32_t interval;
  if (d < 50) {
    interval = 150;
  } else if (d < 100) {
    interval = 400;
  } else {
    noTone(PIN_BUZZER);
    return;
  }
  if (now - lastBeep >= interval) {
    lastBeep = now;
    tone(PIN_BUZZER, 2000, 60);
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);
  pinMode(PIN_BUZZER, OUTPUT);
  Wire.begin(21, 22);
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Parking sensor");
  delay(1000);
  lcd.clear();
}

void loop() {
  float raw = readDistanceCm();
  if (isnan(raw)) {
    if (++errorCount >= 3) {
      showError();
      noTone(PIN_BUZZER);
    }
    delay(100);
    return;
  }
  errorCount = 0;
  float dist = movingAverage(raw);
  Serial.println(dist);
  showDistance(dist);
  beepForDistance(dist);
  delay(60);
}